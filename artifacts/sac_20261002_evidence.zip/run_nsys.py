"""Wait for the final checks, then record an isolated Nsight diagnostic."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
root = out.parent.parent
pid = int(sys.argv[1])
deadline = time.monotonic() + 2400
while Path(f"/proc/{pid}/cmdline").exists():
    if b"final_checks.py" not in Path(f"/proc/{pid}/cmdline").read_bytes():
        break
    if time.monotonic() > deadline:
        raise TimeoutError("Final checks did not exit")
    time.sleep(2)
occupied = subprocess.check_output([
    "nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip()
if occupied:
    raise RuntimeError(f"Refusing to overlap existing GPU work: {occupied}")
env = os.environ | {
    "PYTHONPATH": ":".join(str(root / p / "src") for p in ("UniLab", "unilab_rl", "unisim")),
    "PYTHONUNBUFFERED": "1", "NCCL_SHM_DISABLE": "0", "NCCL_DEBUG": "WARN",
}
prefix = out / "nsys_steady"
command = ["nsys", "profile", "--trace=cuda,nvtx,osrt", "--sample=none",
    "--cpuctxsw=none", "--capture-range=cudaProfilerApi", "--capture-range-end=stop",
    "--cuda-graph-trace=node", "-o", str(prefix), sys.executable,
    str(out / "nsys_training.py"), "task=g1_walk_flat/mujoco", "training.no_play=true",
    "algo.max_iterations=210", "training.devices=[0,1]", "training.trace_enabled=false",
    f"training.log_dir={out / 'nsys_training'}"]
(out / "nsys_invocation.json").write_text(json.dumps(command, indent=2))
with (out / "nsys_training.log").open("w") as log:
    result = subprocess.run(command, cwd=root / "UniLab", env=env, stdout=log, stderr=subprocess.STDOUT)
if result.returncode:
    raise SystemExit(result.returncode)
with (out / "nsys_stats.log").open("w") as log:
    subprocess.run(["nsys", "stats", "--report", "cuda_gpu_kern_sum,cuda_api_sum,nvtx_sum",
        "--format", "csv", str(prefix) + ".nsys-rep"], stdout=log, stderr=subprocess.STDOUT, check=True)
print("NSYS completed", flush=True)
