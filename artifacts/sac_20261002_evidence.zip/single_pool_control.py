"""Single-GPU control using the same local pool as one optimized DP rank."""
import json
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
root = out.parent.parent
occupied = subprocess.check_output([
    "nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip()
if occupied:
    raise RuntimeError(f"Refusing to overlap GPU work: {occupied}")
subprocess.run([sys.executable, str(out / "run_matrix.py"), "n1", "--prefix", "local32",
    "--repeats", "3", "--override", "+env.cpu_ids=" + json.dumps(list(range(8, 40)), separators=(",", ":"))],
    cwd=root / "UniLab", check=True)
