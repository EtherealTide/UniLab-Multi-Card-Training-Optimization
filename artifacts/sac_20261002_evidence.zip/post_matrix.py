"""Run diagnostics only after the sequential throughput matrix has exited."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from analyze_run import analyze

output = Path(__file__).resolve().parent
root = output.parent.parent
pid = int(sys.argv[1])
deadline = time.monotonic() + 3600
while Path(f"/proc/{pid}/cmdline").exists():
    if b"run_matrix.py" not in Path(f"/proc/{pid}/cmdline").read_bytes():
        break
    if time.monotonic() > deadline:
        raise TimeoutError("Throughput matrix did not exit")
    time.sleep(2)

env = os.environ | {
    "PYTHONPATH": ":".join(str(root / p / "src") for p in ("UniLab", "unilab_rl", "unisim")),
    "PYTHONUNBUFFERED": "1", "NCCL_SHM_DISABLE": "0", "NCCL_DEBUG": "INFO",
}


def run(name, command, environment):
    print("START", name, flush=True)
    with (output / f"{name}.log").open("w") as log:
        result = subprocess.run(command, env=environment, cwd=root / "UniLab",
                                stdout=log, stderr=subprocess.STDOUT)
    print("END", name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


name = "diagnostic_v3_retry"
run_dir = output / name
assert not run_dir.exists(), "Preserve existing diagnostic run"
run(name, [sys.executable, str(output / "profile_training.py"),
           "task=g1_walk_flat/mujoco", "training.no_play=true", "algo.max_iterations=1000",
           "training.devices=[0,1]", "training.trace_enabled=true", f"training.log_dir={run_dir}"], env)
(output / f"{name}_metrics.json").write_text(json.dumps(analyze(run_dir), indent=2))
for transport, disable in (("shm", "0"), ("net", "1")):
    name = f"comm_exact_{transport}"
    run(name, [sys.executable, str(output / "dp_probe.py"), "communication",
               "--bytes", "4", "896976", "3936444", "--output", str(output / f"{name}.json")],
        env | {"CUDA_VISIBLE_DEVICES": "0,1", "NCCL_SHM_DISABLE": disable})
