"""Final bounded CPU pool/protocol controls after all other GPU jobs exit."""
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
root = out.parent.parent
occupied = subprocess.check_output([
    "nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip()
if occupied:
    raise RuntimeError(f"Refusing to overlap GPU work: {occupied}")
env = os.environ | {"PYTHONPATH": ":".join(str(root / p / "src") for p in ("UniLab", "unilab_rl", "unisim")),
                    "NCCL_SHM_DISABLE": "0", "CUDA_VISIBLE_DEVICES": "0,1"}

def run(name, command, changes=None):
    (out / f"{name}_invocation.json").write_text(json.dumps({"command": command,
        "extra_environment": changes or {}}, indent=2))
    print("START", name, flush=True)
    with (out / f"{name}.log").open("w") as log:
        completed = subprocess.run(command, env=env | (changes or {}), cwd=root / "UniLab",
                                   stdout=log, stderr=subprocess.STDOUT)
    print("END", name, completed.returncode, flush=True)
    if completed.returncode:
        raise SystemExit(completed.returncode)

matrix = [sys.executable, str(out / "run_matrix.py"), "n2_shm", "--trace"]
pool = [list(range(8, 40)), list(range(48, 80))]
run("pool_reserved", matrix + ["--prefix", "pool_reserved", "--override",
    "training.dp_collector_cpu_ids=" + json.dumps(pool, separators=(",", ":"))])
run("simple", matrix + ["--prefix", "simple"], {"NCCL_PROTO": "Simple"})
run("comm_simple", [sys.executable, str(out / "dp_probe.py"), "communication", "--bytes",
    "4", "896976", "3936444", "--output", str(out / "comm_simple.json")], {"NCCL_PROTO": "Simple"})
run("correctness_simple", [sys.executable, str(out / "dp_probe.py"), "correctness",
    "--output", str(out / "correctness_simple.json")], {"NCCL_PROTO": "Simple"})
