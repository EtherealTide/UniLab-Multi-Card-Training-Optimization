"""Export a reviewable patch and a compact evidence archive (no checkpoints)."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

out = Path(__file__).resolve().parent
root = out.parent.parent
repo = root / "unilab_rl"
new_test = "tests/algos/test_dp_graph_lifecycle.py"
patch = subprocess.check_output(["git", "diff", "--binary"], cwd=repo)
new_diff = subprocess.run(["git", "diff", "--no-index", "--binary", "--", "/dev/null", new_test],
                          cwd=repo, capture_output=True)
assert new_diff.returncode == 1, new_diff.stderr
patch += new_diff.stdout
(out / "unilab_rl_optimization.patch").write_bytes(patch)
subprocess.run(["git", "apply", "--reverse", "--check", str(out / "unilab_rl_optimization.patch")],
               cwd=repo, check=True)
changed = subprocess.check_output(["git", "diff", "--name-only"], cwd=repo, text=True).splitlines()
for relative in changed + [new_test]:
    target = out / "source" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((repo / relative).read_bytes())
paths = [p for p in out.iterdir() if p.is_file() and p.name != "evidence_manifest.json"
         and p.suffix in {".json", ".log", ".py", ".md", ".patch"}]
paths += list((out / "source").rglob("*.py"))
if (out / "nsys_steady.nsys-rep").exists():
    paths.append(out / "nsys_steady.nsys-rep")
for directory in out.iterdir():
    if not directory.is_dir() or directory.name in {"source", "results", "__pycache__"}:
        continue
    paths += [p for p in directory.iterdir() if p.is_file() and (
        p.name in {"run_config.json", "run_summary.json"} or p.name.startswith("events.out.tfevents"))]
for name in ("collective_events_rank0.json", "collective_events_rank1.json", "perfetto_offpolicy_timeline.json"):
    path = out / "diagnostic_v3_retry" / name
    if path.exists():
        paths.append(path)
manifest = {str(p.relative_to(out)): {"bytes": p.stat().st_size,
    "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(set(paths))}
(out / "evidence_manifest.json").write_text(json.dumps(manifest, indent=2))
with zipfile.ZipFile(out / "sac_experiment_evidence.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(paths)):
        archive.write(path, path.relative_to(out))
    archive.write(out / "evidence_manifest.json", "evidence_manifest.json")
print(json.dumps({"files": len(manifest), "archive_bytes": (out / "sac_experiment_evidence.zip").stat().st_size,
                  "patch_bytes": len(patch)}))
