"""Three alternating runs with equal aggregate MuJoCo physical-core pools."""
import json
from pathlib import Path
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
root = out.parent.parent
for attempt in range(30):
    occupied = subprocess.check_output([
        "nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip()
    if not occupied:
        break
    time.sleep(2)
else:
    raise RuntimeError(f"Refusing to overlap GPU work: {occupied}")
pools = [list(range(8, 40)), list(range(48, 80))]
for repeat in range(1, 4):
    for case in ("n1", "n2_shm"):
        override = ("+env.cpu_ids=" + json.dumps(pools[0] + pools[1], separators=(",", ":"))
                    if case == "n1" else "training.dp_collector_cpu_ids=" + json.dumps(pools, separators=(",", ":")))
        command = [sys.executable, str(out / "run_matrix.py"), case,
                   "--prefix", f"pool_final_r{repeat}", "--override", override]
        subprocess.run(command, cwd=root / "UniLab", check=True)
