"""Compare identical reserved-core budgets on single and dual GPUs."""
import json
from pathlib import Path
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
root = out.parent.parent
pid = int(sys.argv[1])
while Path(f"/proc/{pid}/cmdline").exists():
    if b"run_nsys.py" not in Path(f"/proc/{pid}/cmdline").read_bytes():
        break
    time.sleep(2)
occupied = subprocess.check_output([
    "nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip()
if occupied:
    raise RuntimeError(f"Refusing to overlap GPU work: {occupied}")
command = ["taskset", "--cpu-list", "8-39,48-79", sys.executable,
           str(out / "run_matrix.py"), "n1", "n2_shm", "--prefix", "reserved", "--trace"]
(out / "reserved_invocation.json").write_text(json.dumps(command, indent=2))
subprocess.run(command, cwd=root / "UniLab", check=True)
