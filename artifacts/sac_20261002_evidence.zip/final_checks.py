"""Serial follow-up experiments and correctness checks; never overlap GPU jobs."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
root = out.parent.parent
pid = int(sys.argv[1])
while Path(f"/proc/{pid}/cmdline").exists():
    if b"run_matrix.py" not in Path(f"/proc/{pid}/cmdline").read_bytes():
        break
    time.sleep(2)
env = os.environ | {
    "PYTHONPATH": ":".join(str(root / p / "src") for p in ("UniLab", "unilab_rl", "unisim")),
    "PYTHONUNBUFFERED": "1", "NCCL_SHM_DISABLE": "0", "NCCL_DEBUG": "WARN",
}

def run(name, command, changes=None):
    environment = env | (changes or {})
    print("START", name, flush=True)
    (out / f"{name}_invocation.json").write_text(json.dumps({
        "command": command, "environment_overrides": changes or {},
    }, indent=2))
    with (out / f"{name}.log").open("w") as log:
        result = subprocess.run(command, env=environment, cwd=root / "UniLab",
                                stdout=log, stderr=subprocess.STDOUT)
    print("END", name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

matrix = [sys.executable, str(out / "run_matrix.py"), "n2_shm"]
run("nomix_clean", matrix + ["--prefix", "nomix_clean", "--trace"],
    {"NCCL_GRAPH_MIXING_SUPPORT": "0"})
run("graph_order", matrix + ["--prefix", "graph_order", "--trace"],
    {"NCCL_GRAPH_MIXING_SUPPORT": "0", "NCCL_GRAPH_STREAM_ORDERING": "0"})
run("numa0", ["numactl", "--cpunodebind=0", "--membind=0"] + matrix +
    ["--prefix", "numa0", "--trace"])
for compiled in (False, True):
    name = "enhanced_compiled" if compiled else "enhanced_correctness"
    command = [sys.executable, str(out / "dp_probe.py"), "correctness", "--output", str(out / f"{name}.json")]
    if compiled:
        command.append("--compile-loss")
    run(name, command, {"CUDA_VISIBLE_DEVICES": "0,1"})
run("final_cuda_tests", ["uv", "run", "--no-sync", "pytest",
    str(root / "unilab_rl/tests/algos/test_fast_sac_compile.py"), "-q"],
    {"CUDA_VISIBLE_DEVICES": "0"})
