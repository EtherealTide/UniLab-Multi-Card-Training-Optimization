"""Summarize a captured Nsight SQLite export without rewriting it."""
import json
from pathlib import Path
import sqlite3

out = Path(__file__).resolve().parent
connection = sqlite3.connect(f"file:{out / 'nsys_steady.sqlite'}?mode=ro", uri=True)
connection.row_factory = sqlite3.Row

def query(sql):
    return [dict(row) for row in connection.execute(sql)]

tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
result = {"tables": sorted(tables)}
if "CUPTI_ACTIVITY_KIND_KERNEL" in tables:
    columns = {row[1] for row in connection.execute("PRAGMA table_info(CUPTI_ACTIVITY_KIND_KERNEL)")}
    name = "shortName" if "shortName" in columns else "demangledName"
    base = f"FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON k.{name}=s.id"
    result["kernel_totals"] = query(f"""SELECT s.value AS name, COUNT(*) AS calls,
        SUM(k.end-k.start)/1e6 AS total_ms, AVG(k.end-k.start)/1e6 AS mean_ms,
        MAX(k.end-k.start)/1e6 AS max_ms {base} GROUP BY s.value ORDER BY total_ms DESC LIMIT 20""")
    result["nccl_kernels"] = query(f"""SELECT deviceId, k.start, k.end,
        (k.end-k.start)/1e6 AS ms, correlationId, s.value AS name
        {base} WHERE lower(s.value) LIKE '%nccl%' ORDER BY k.start""")
    result["long_kernels"] = query(f"""SELECT deviceId, k.start, k.end,
        (k.end-k.start)/1e6 AS ms, correlationId, s.value AS name
        {base} ORDER BY ms DESC LIMIT 30""")
for table in ("CUPTI_ACTIVITY_KIND_RUNTIME", "CUPTI_ACTIVITY_KIND_DRIVER"):
    if table in tables:
        result[table] = query(f"""SELECT s.value AS name, COUNT(*) AS calls,
          AVG(k.end-k.start)/1e6 AS mean_ms, MAX(k.end-k.start)/1e6 AS max_ms
          FROM {table} k JOIN StringIds s ON k.nameId=s.id GROUP BY s.value
          ORDER BY SUM(k.end-k.start) DESC LIMIT 20""")
(out / "nsys_analysis.json").write_text(json.dumps(result, indent=2))
print(json.dumps({key: value for key, value in result.items() if key not in {"nccl_kernels", "tables"}}, indent=2))
